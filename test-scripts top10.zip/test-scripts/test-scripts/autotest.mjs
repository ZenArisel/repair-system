// ทดสอบอัตโนมัติ F1-F12 / P1-P10 ของระบบแจ้งซ่อม (ใช้กับระบบของตนเองเท่านั้น)
// เตรียม:  npm i playwright @neondatabase/serverless && npx playwright install chromium
// รัน:     DATABASE_URL="postgres://..." node autotest.mjs
// (BASE_URL ไม่ใส่ก็ได้ ค่าเริ่มต้นคือเว็บ Vercel ของคุณ)  ผลอยู่ที่ results.md, results.json, evidence/*.png
import { chromium } from 'playwright';
import { neon } from '@neondatabase/serverless';
import fs from 'fs';

const BASE = (process.env.BASE_URL || 'https://repair-system-green.vercel.app').replace(/\/$/, '');
if (!process.env.DATABASE_URL) { console.error('ต้องตั้ง DATABASE_URL (ค่าเดียวกับใน Vercel/.env.local)'); process.exit(1); }
const sql = neon(process.env.DATABASE_URL);
const uid = Date.now().toString(36);
const PW = 'Test1234pass', PHONE = '0812345678';
const em = (k) => `qa-${k}-${uid}@example.com`;
const maskEmail = (e) => { const [u, d] = e.split('@'); return `${u[0]}${'*'.repeat(Math.max(u.length - 1, 2))}@${d}`; };
fs.mkdirSync('evidence', { recursive: true });

const results = [];
const ok = (c, m) => { if (!c) throw new Error(m); };
const settle = (p, ms = 1500) => p.waitForTimeout(ms);
const see = (p, t) => p.getByText(t).first().waitFor({ state: 'visible', timeout: 10000 });
const shot = (p, id) => p.screenshot({ path: `evidence/${id}.png`, fullPage: true }).catch(() => {});
async function t(id, name, fn) {
  try { const note = await fn(); results.push({ id, name, pass: true, note: note || '' }); console.log(`PASS ${id} ${name}`); }
  catch (e) { results.push({ id, name, pass: false, note: String(e.message).split('\n')[0] }); console.log(`FAIL ${id} ${name} -> ${String(e.message).split('\n')[0]}`); }
}
const browser = await chromium.launch();
const dialogs = [];
async function newCtx() { const ctx = await browser.newContext({ baseURL: BASE, locale: 'th-TH' }); const page = await ctx.newPage();
  page.on('dialog', (d) => { dialogs.push(d.type()); d.accept(); }); return { ctx, page }; }
async function register(email, name, pw = PW, phone = PHONE) {
  const s = await newCtx(); await s.page.goto('/register'); await s.page.waitForLoadState('networkidle');
  await s.page.fill('input[name=name]', name); await s.page.fill('input[name=email]', email);
  await s.page.fill('input[name=phone]', phone); await s.page.fill('input[name=password]', pw);
  await s.page.click('form button:has-text("สมัครสมาชิก")'); return s;
}
async function home(p) { await p.goto('/'); await p.waitForLoadState('networkidle'); }
async function newTicket(p, title, desc = 'รายละเอียดทดสอบ') {
  await p.goto('/tickets/new'); await p.waitForLoadState('networkidle');
  await p.fill('input[name=title]', title); await p.fill('input[name=location]', 'อาคารทดสอบ'); await p.fill('textarea[name=description]', desc);
  await p.click('form:has(input[name=title]) button:has-text("ส่งใบแจ้งซ่อม")'); await settle(p);
}
const formFields = (loc) => loc.evaluate((el) => Object.fromEntries([...new FormData(el).entries()].map(([k, v]) => [k, String(v)])));
const uidOf = async (email) => (await sql`SELECT id FROM users WHERE email=${email}`)[0]?.id;
const tid = async (title) => (await sql`SELECT id,status FROM tickets WHERE title=${title}`)[0];

// ---------- เตรียมผู้ใช้ ----------
const A = await register(em('a'), `ทดสอบ A ${uid}`), B = await register(em('b'), `ทดสอบ B ${uid}`),
  ADM = await register(em('adm'), `ทดสอบ Admin ${uid}`), C = await register(em('c'), `ทดสอบ C ${uid}`);
await Promise.all([A, B, ADM, C].map((s) => s.page.waitForURL((u) => u.pathname === '/', { timeout: 15000 }).catch(() => {})));
await sql`UPDATE users SET role='admin',verify_status='approved' WHERE email=${em('adm')}`;
await sql`UPDATE users SET verify_status='approved' WHERE email=${em('b')}`;

await t('F1', 'สมัครสมาชิกด้วยข้อมูลถูกต้อง', async () => { await see(A.page, `สวัสดี ทดสอบ A`); await shot(A.page, 'F1'); });
await t('F2', 'สมัครอีเมลซ้ำ / รหัสผ่านอ่อน', async () => {
  const d = await register(em('a'), 'ซ้ำ ซ้ำ'); await see(d.page, 'อีเมลนี้ถูกใช้แล้ว'); await shot(d.page, 'F2a'); await d.ctx.close();
  const w = await register(em('weak'), 'อ่อน อ่อน', '12345678'); await see(w.page, 'รหัสผ่านต้อง'); await shot(w.page, 'F2b'); await w.ctx.close(); });
await t('F3', 'password_hash เป็น bcrypt $2a$12$', async () => {
  const h = (await sql`SELECT password_hash FROM users WHERE email=${em('a')}`)[0].password_hash;
  ok(h.startsWith('$2a$12$'), `prefix=${h.slice(0, 7)}`); return `SELECT left(password_hash,7), length(password_hash) FROM users WHERE email='${em('a')}'\n=> ${h.slice(0, 7)} , ${h.length} ตัวอักษร (รหัสผ่านเดิมไม่ถูกเก็บ)`; });

await t('F12a', 'ยังไม่อนุมัติ: เปิด /tickets/new ถูกส่งไป /verify', async () => {
  await A.page.goto('/tickets/new'); await A.page.waitForURL(/\/verify/, { timeout: 10000 }); });
const reqVerify = async (s, name) => { await s.page.goto('/verify'); await s.page.waitForLoadState('networkidle');
  await s.page.fill('input[name=real_name]', name); await s.page.fill('input[name=department]', 'ฝ่ายทดสอบ'); await s.page.fill('input[name=building]', 'ตึก T');
  await s.page.fill('textarea[name=reason]', 'ทดสอบระบบ'); await s.page.click('form:has(input[name=real_name]) button:has-text("ส่งคำขอ")'); await settle(s.page); };
await t('F12', 'ส่งคำขอยืนยัน แล้ว admin อนุมัติผ่านหน้า /admin', async () => {
  await reqVerify(A, `นายทดสอบเอ ${uid}`); await reqVerify(C, `นายทดสอบซี ${uid}`);
  await see(A.page, 'รออนุมัติ'); await shot(A.page, 'F12-pending');
  await ADM.page.goto('/admin?tab=users'); await ADM.page.waitForLoadState('networkidle');
  await ADM.page.locator(`.card:has-text("นายทดสอบเอ ${uid}")`).locator('button:has-text("อนุมัติ")').click(); await settle(ADM.page);
  await shot(ADM.page, 'F12-admin');
  ok((await sql`SELECT verify_status s FROM users WHERE email=${em('a')}`)[0].s === 'approved', 'ยังไม่เป็น approved'); });

const T1 = `ปั๊มน้ำเสีย ${uid}`, T2 = `ลบทิ้ง ${uid}`, T3 = `xss ${uid}`;
await t('F5', 'user แจ้งซ่อม (ฟอร์ม 1) บันทึกลง DB และแสดงผล', async () => {
  await newTicket(A.page, T1); await home(A.page); await see(A.page, T1); await see(A.page, 'รอดำเนินการ');
  ok(await tid(T1), 'ไม่พบใน DB'); await shot(A.page, 'F5'); });
await t('F6', 'user แก้ไข/ลบใบของตน (สถานะรอดำเนินการ)', async () => {
  await A.page.locator(`article:has-text("${T1}")`).locator('a:has-text("แก้ไข")').click(); await A.page.waitForLoadState('networkidle');
  await A.page.fill('input[name=title]', `${T1} (แก้)`); await A.page.click('form:has(input[name=title]) button:has-text("บันทึก")'); await settle(A.page);
  ok(await tid(T1 + ' (แก้)'), 'แก้ไขไม่ถูกบันทึก');
  await sql`UPDATE tickets SET title=${T1} WHERE title=${T1 + ' (แก้)'}`; // คืนชื่อเดิมเพื่อใช้ทดสอบข้อถัดไป
  await newTicket(A.page, T2); await home(A.page);
  await A.page.locator(`article:has-text("${T2}")`).locator('button:has-text("ยกเลิก/ลบ")').click(); await settle(A.page);
  ok(!(await tid(T2)), 'ลบไม่สำเร็จ'); await shot(A.page, 'F6'); });
await t('P8', 'Mass assignment: ส่ง category แปลก ๆ ถูกปฏิเสธ', async () => {
  const T = `mass ${uid}`; await A.page.goto('/tickets/new'); await A.page.waitForLoadState('networkidle');
  await A.page.fill('input[name=title]', T); await A.page.fill('input[name=location]', 'x'); await A.page.fill('textarea[name=description]', 'x');
  await A.page.evaluate(() => { document.querySelector('select[name=category]').innerHTML = '<option value="hack">x</option>'; });
  await A.page.click('form:has(input[name=title]) button:has-text("ส่งใบแจ้งซ่อม")'); await settle(A.page, 2000);
  ok(!(await tid(T)), 'ระบบรับค่า category ปลอม'); await shot(A.page, 'P8'); });
await t('P7', 'Stored XSS แสดงเป็นข้อความ ไม่รันสคริปต์', async () => {
  const before = dialogs.length; await newTicket(A.page, T3, '<img src=x onerror="alert(1);window.__xss=1"><script>window.__xss=1</script>'); await home(A.page);
  await see(A.page, '<img src=x'); await settle(A.page);
  ok(!(await A.page.evaluate(() => window.__xss)), 'สคริปต์ถูกรัน'); ok(!dialogs.slice(before).includes('alert'), 'มี alert เด้ง'); await shot(A.page, 'P7'); });
await t('P2', 'user B ไม่เห็นใบของ A', async () => { await home(B.page); const x = await B.page.content(); ok(!x.includes(T1) && !x.includes(T3), 'เห็นใบของผู้อื่น'); await shot(B.page, 'P2'); });
await t('P1', 'IDOR: B เปิดหน้าแก้ใบของ A และยิงคำสั่งลบซ้ำด้วยสิทธิ์ B', async () => {
  const tk = await tid(T1); const r = await B.page.goto(`/tickets/${tk.id}/edit`); ok(r.status() === 404, `status=${r.status()} (ควร 404)`); await shot(B.page, 'P1');
  await home(A.page); const fields = await formFields(A.page.locator(`article:has-text("${T1}") form`).first());
  await B.ctx.request.post(BASE + '/', { multipart: fields }).catch(() => {}); await settle(B.page, 800);
  ok(await tid(T1), 'ใบของ A ถูก B ลบได้'); return 'ยิง Server Action ลบด้วยคุกกี้ของ B แล้ว ใบของ A ยังอยู่'; });

await t('F7', 'admin เปลี่ยนสถานะเป็นซ่อมเสร็จ + บันทึกผล -> user เห็น', async () => {
  await ADM.page.goto(`/admin?tab=tickets&q=${encodeURIComponent(T1)}`); await ADM.page.waitForLoadState('networkidle');
  const art = ADM.page.locator(`article:has-text("${T1}")`); await art.locator('select[name=status]').selectOption('done');
  await art.locator('input[name=admin_note]').fill('เปลี่ยนปั๊มเรียบร้อย'); await art.locator('button:has-text("อัปเดต")').click(); await settle(ADM.page); await shot(ADM.page, 'F7-admin');
  await home(A.page); await see(A.page, 'ซ่อมเสร็จ'); await see(A.page, 'เปลี่ยนปั๊มเรียบร้อย'); await shot(A.page, 'F7'); });
await t('F8', 'user แก้/ลบใบที่เปลี่ยนสถานะแล้วไม่ได้', async () => {
  const tk = await tid(T1); ok(await A.page.locator(`article:has-text("${T1}") a:has-text("แก้ไข")`).count() === 0, 'ยังมีปุ่มแก้ไข');
  const r = await A.page.goto(`/tickets/${tk.id}/edit`); ok(r.status() === 404, `status=${r.status()}`); await shot(A.page, 'F8'); });
await t('F9', 'ประเมินหลังซ่อมเสร็จ บันทึกได้ครั้งเดียว', async () => {
  await home(A.page); const art = A.page.locator(`article:has-text("${T1}")`); await art.locator('input[name=comment]').fill('พอใจมาก'); await art.locator('button:has-text("ส่งประเมิน")').click(); await settle(A.page);
  await home(A.page); ok(await A.page.locator(`article:has-text("${T1}") .rate`).count() === 0, 'ฟอร์มประเมินยังอยู่');
  const tk = await tid(T1); ok((await sql`SELECT count(*)::int n FROM ratings WHERE ticket_id=${tk.id}`)[0].n === 1, 'จำนวนประเมินไม่เท่ากับ 1'); await shot(A.page, 'F9'); });
await t('F10', 'อีเมล/เบอร์ถูกปิดบัง และแก้โปรไฟล์ได้', async () => {
  await A.page.goto('/profile'); await A.page.waitForLoadState('networkidle'); const body = await A.page.locator('body').innerText();
  ok(body.includes(maskEmail(em('a'))) && body.includes('081-xxx-5678'), 'ไม่พบข้อความที่ถูก mask'); ok(!body.includes(em('a')), 'เห็นอีเมลเต็มในหน้า');
  await A.page.fill('input[name=phone]', '0899999999'); await A.page.click('form:has(input[name=phone]) button:has-text("บันทึก")'); await settle(A.page);
  await see(A.page, '089-xxx-9999'); await shot(A.page, 'F10'); });
results.push({ id: 'F11', name: 'ล็อกอินด้วย Google', pass: null, note: 'ต้องทำเอง (ต้องใช้บัญชี Google) แล้วแคปหน้าจอ' });

await t('P3', 'user ทั่วไปเปิด /admin ถูกส่งกลับหน้าแรก', async () => {
  await B.page.goto('/admin'); await B.page.waitForLoadState('networkidle'); ok(new URL(B.page.url()).pathname === '/', `url=${B.page.url()}`); await shot(B.page, 'P3'); });
await t('P4', 'user ยิง Server Action ของ admin (setStatus / approveUser) ถูกปฏิเสธ', async () => {
  await ADM.page.goto(`/admin?tab=tickets&q=${encodeURIComponent(T3)}`); await ADM.page.waitForLoadState('networkidle');
  const f1 = await formFields(ADM.page.locator(`article:has-text("${T3}") form:has(select[name=status])`).first()); f1.status = 'rejected';
  await ADM.page.goto('/admin?tab=users'); await ADM.page.waitForLoadState('networkidle');
  const f2 = await formFields(ADM.page.locator(`.card:has-text("นายทดสอบซี ${uid}") form:has(button:has-text("อนุมัติ"))`).first());
  for (const f of [f1, f2]) await B.ctx.request.post(BASE + '/', { multipart: f }).catch(() => {}); await settle(B.page, 800);
  ok((await tid(T3)).status === 'pending', 'B เปลี่ยนสถานะใบได้'); ok((await sql`SELECT verify_status s FROM users WHERE email=${em('c')}`)[0].s === 'pending', 'B อนุมัติผู้ใช้ได้');
  return `user ธรรมดา (B) ยิง setStatus และ approveUser ของ admin\nสถานะใบแจ้งซ่อมหลังยิง: ${(await tid(T3)).status} (ไม่เปลี่ยน)\nสถานะผู้ใช้ C หลังยิง: pending (ไม่เปลี่ยน)`; });
await t('P5', 'JWT ปลอม (alg=none) และ token ที่ถูกแก้ ใช้ไม่ได้', async () => {
  const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url'); const host = new URL(BASE).hostname;
  const good = (await A.ctx.cookies()).find((c) => c.name === 'session').value;
  for (const tok of [`${b64({ alg: 'none', typ: 'JWT' })}.${b64({ sub: '1' })}.`, good.slice(0, -2) + (good.endsWith('AA') ? 'BB' : 'AA')]) {
    const s = await newCtx(); await s.ctx.addCookies([{ name: 'session', value: tok, domain: host, path: '/' }]);
    await s.page.goto('/admin'); await s.page.waitForLoadState('networkidle'); ok(new URL(s.page.url()).pathname === '/login', `url=${s.page.url()}`); await shot(s.page, 'P5'); await s.ctx.close(); } });
await t('P6', 'SQL Injection ในหน้าล็อกอิน', async () => {
  const s = await newCtx(); await s.page.goto('/login'); await s.page.waitForLoadState('networkidle');
  await s.page.evaluate(() => { document.querySelector('input[name=email]').type = 'text'; });
  await s.page.fill('input[name=email]', "' OR 1=1--"); await s.page.fill('input[name=password]', "' OR '1'='1"); await s.page.click('form button:has-text("เข้าสู่ระบบ")'); await settle(s.page);
  ok(new URL(s.page.url()).pathname === '/login', 'หลุดเข้าระบบได้'); await see(s.page, 'อีเมลหรือรหัสผ่านไม่ถูกต้อง'); await shot(s.page, 'P6'); await s.ctx.close(); });
await t('F4', 'ล็อกอินผิด 5 ครั้ง บัญชีถูกล็อก (ครอบคลุม P9 Brute force)', async () => {
  const L = await register(em('lock'), 'ทดสอบ ล็อก'); await L.page.waitForURL((u) => u.pathname === '/', { timeout: 15000 }); await L.ctx.close();
  const s = await newCtx(); await s.page.goto('/login'); await s.page.waitForLoadState('networkidle');
  for (let i = 0; i < 5; i++) { await s.page.fill('input[name=email]', em('lock')); await s.page.fill('input[name=password]', 'Wrong1234x'); await s.page.click('form button:has-text("เข้าสู่ระบบ")'); await settle(s.page, 1800); }
  await s.page.fill('input[name=email]', em('lock')); await s.page.fill('input[name=password]', PW); await s.page.click('form button:has-text("เข้าสู่ระบบ")');
  await see(s.page, 'บัญชีถูกล็อกชั่วคราว'); ok((await sql`SELECT locked_until FROM users WHERE email=${em('lock')}`)[0].locked_until, 'locked_until ว่าง'); await shot(s.page, 'F4'); await s.ctx.close(); });
{ const f4 = results.find((r) => r.id === 'F4'); if (f4) results.push({ ...f4, id: 'P9', name: 'Brute force: ผิด 5 ครั้งถูกล็อก (ผลเดียวกับ F4)' }); }
await t('P10', 'Security headers + cookie flags + OAuth callback ถูกปฏิเสธ', async () => {
  const r = await A.ctx.request.get(BASE + '/login'); const h = r.headers(); const miss = ['content-security-policy', 'strict-transport-security', 'x-frame-options', 'x-content-type-options'].filter((k) => !h[k]);
  ok(!miss.length, 'ขาด header: ' + miss.join(', ')); const c = (await A.ctx.cookies()).find((x) => x.name === 'session'); ok(c.httpOnly && c.secure && c.sameSite === 'Lax', `cookie flags ผิด ${JSON.stringify({ h: c.httpOnly, s: c.secure, ss: c.sameSite })}`);
  const o = await A.ctx.request.get(BASE + '/api/auth/google/callback?code=x&state=y', { maxRedirects: 0 }); ok(o.status() >= 300 && o.status() < 400 && (o.headers().location || '').includes('/login'), `OAuth callback status=${o.status()}`);
  return ['content-security-policy', 'strict-transport-security', 'x-frame-options', 'x-content-type-options'].map((k) => `${k}: ${h[k]}`).join('\n')
    + `\ncookie session: HttpOnly=${c.httpOnly} Secure=${c.secure} SameSite=${c.sameSite}\nOAuth callback ปลอม: HTTP ${o.status()} -> ${o.headers().location}\n(npm audit ต้องรันเอง)`; });

// ---------- สรุป + ล้างข้อมูลทดสอบ ----------
if (!process.env.KEEP) await sql`DELETE FROM users WHERE email LIKE ${'qa-%-' + uid + '@example.com'}`;
const esc = (x) => String(x).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
const cp = await browser.newPage({ viewport: { width: 980, height: 500 } });
for (const r of results) {
  if (r.pass === null || fs.existsSync(`evidence/${r.id}.png`)) continue;
  if (r.id === 'P9' && fs.existsSync('evidence/F4.png')) { fs.copyFileSync('evidence/F4.png', 'evidence/P9.png'); continue; }
  const col = r.pass ? '#2e7d32' : '#c62828';
  await cp.setContent(`<body style="font-family:Tahoma,'Noto Sans Thai',sans-serif;margin:0;padding:20px;background:#fff"><div style="border:3px solid ${col};border-radius:12px;padding:22px;max-width:900px">
    <div style="color:#666;font-size:14px">${esc(BASE)} · ทดสอบเมื่อ ${new Date().toLocaleString('th-TH')}</div>
    <h2 style="margin:10px 0 6px;color:#1f3864">${esc(r.id)} — ${esc(r.name)}</h2>
    <div style="font-size:24px;font-weight:bold;color:${col};margin:8px 0">${r.pass ? '✔ ผ่าน' : '✘ ไม่ผ่าน'}</div>
    <pre style="white-space:pre-wrap;font-family:Consolas,Tahoma,monospace;font-size:15px;background:#f4f6fa;padding:12px;border-radius:8px;margin:0">${esc(r.note || 'ผลตรวจตรงตามที่คาดหวัง')}</pre></div></body>`);
  await cp.locator('body > div').screenshot({ path: `evidence/${r.id}.png` });
}
await browser.close();
const order = (r) => (r.id[0] === 'F' ? 0 : 1) * 1000 + parseInt(r.id.replace(/\D/g, ''));
results.sort((a, b) => order(a) - order(b));
const mark = (p) => (p === null ? 'ทำเอง' : p ? 'ผ่าน' : 'ไม่ผ่าน');
fs.writeFileSync('results.json', JSON.stringify(results, null, 2));
fs.writeFileSync('results.md', '| ID | กรณีทดสอบ | ผล | หมายเหตุ |\n|---|---|---|---|\n' + results.map((r) => `| ${r.id} | ${r.name} | ${mark(r.pass)} | ${String(r.note).replace(/\n/g, ' ; ')} |`).join('\n') + '\n');
console.log(`\nสรุป: ผ่าน ${results.filter((r) => r.pass === true).length} / ไม่ผ่าน ${results.filter((r) => r.pass === false).length} / ทำเอง ${results.filter((r) => r.pass === null).length}  (ดู results.md และโฟลเดอร์ evidence)`);
