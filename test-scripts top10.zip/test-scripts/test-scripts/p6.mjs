// ทดสอบ P6 (SQL Injection หน้าล็อกอิน) ซ้ำ: รัน  node p6.mjs
import { chromium } from 'playwright';
import fs from 'fs';
const BASE = (process.env.BASE_URL || 'https://repair-system-green.vercel.app').replace(/\/$/, '');
fs.mkdirSync('evidence', { recursive: true });
const browser = await chromium.launch();
let allOk = true;
const cases = [
  { name: "อีเมล ' OR 1=1--", email: "' OR 1=1--", pw: "' OR '1'='1", forceText: true },
  { name: "อีเมลรูปแบบถูกต้องแต่แทรก SQL", email: "x'--@example.com", pw: "x' OR '1'='1", forceText: false },
];
for (const [i, c] of cases.entries()) {
  const ctx = await browser.newContext({ baseURL: BASE, locale: 'th-TH' }); const page = await ctx.newPage();
  await page.goto('/login'); await page.waitForLoadState('networkidle');
  if (c.forceText) await page.evaluate(() => { document.querySelector('input[name=email]').type = 'text'; });
  await page.fill('input[name=email]', c.email); await page.fill('input[name=password]', c.pw);
  await page.click('form button:has-text("เข้าสู่ระบบ")'); await page.waitForTimeout(4000);
  const cookies = await ctx.cookies(); const hasSession = cookies.some((k) => k.name === 'session');
  const err = await page.locator('.err').allInnerTexts();
  const path = new URL(page.url()).pathname;
  const pass = path === '/login' && !hasSession;
  allOk &&= pass;
  await page.screenshot({ path: `evidence/P6-${i + 1}.png`, fullPage: true });
  console.log(`${pass ? 'PASS' : 'FAIL'}  ${c.name}  url=${path} session=${hasSession} ข้อความที่เห็น=${JSON.stringify(err)}`);
  await ctx.close();
}
await browser.close();
console.log(allOk ? '\nP6 ผ่าน: ล็อกอินด้วย SQL injection ไม่ได้' : '\nP6 ไม่ผ่าน');
