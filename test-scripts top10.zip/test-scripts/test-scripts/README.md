# สคริปต์ทดสอบระบบแจ้งซ่อม (Functional + Pentest)
ใช้ทดสอบระบบของตนเองเท่านั้น (https://repair-system-green.vercel.app)

## ติดตั้งและรัน
```
npm install
npx playwright install chromium
$env:DATABASE_URL="<connection string ของ Neon>"     # PowerShell
node autotest.mjs      # F1-F10, F12, P1-P10 (ยกเว้น F11 Google)
node p6.mjs            # ทดสอบ SQL Injection หน้าล็อกอินซ้ำ
```
ผลลัพธ์: results.md, results.json และภาพหลักฐานในโฟลเดอร์ evidence/ (มีรูปครบทุกข้อ: ข้อที่เป็นหน้าเว็บแคปหน้าจอจริง ข้อที่เป็นการตรวจฐานข้อมูล/คำสั่งเบื้องหลังสร้างเป็นการ์ดผลทดสอบ)
ทำเอง: F11 (ล็อกอิน Google) และ npm audit

## ครอบคลุม
F1 สมัคร, F2 อีเมลซ้ำ/รหัสอ่อน, F3 bcrypt, F4 ล็อกบัญชี (P9), F5 แจ้งซ่อม, F6 แก้/ลบของตน,
F7 admin เปลี่ยนสถานะ, F8 แก้ไม่ได้หลังเปลี่ยนสถานะ, F9 ประเมินครั้งเดียว, F10 masking, F12 ยืนยันตัวตน,
P1 IDOR, P2 ดูใบคนอื่น, P3 /admin, P4 Server Action ของ admin, P5 JWT ปลอม, P6 SQLi,
P7 XSS, P8 mass assignment, P10 headers/cookie/OAuth
